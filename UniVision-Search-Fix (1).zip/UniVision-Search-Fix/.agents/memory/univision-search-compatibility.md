---
name: UniVision search compatibility
description: Why the static UniVision page keeps a classic script entry and public-source media flow.
---

UniVision's existing static HTML relies on browser-global handlers and the current visual structure, so search behavior should be extended without converting the page to a module-only or framework-rendered entry. Search results must never substitute unrelated stock photos when verification fails.

**Why:** The page includes inline retry handlers and a deliberately preserved HTML/CSS design; changing the script model or rebuilding the UI can silently break those interactions, while unrelated fallback images would violate the product's source-verification promise.

**How to apply:** Keep `app.js` globally available, preserve the existing markup and styles, and prefer public sources plus an explicit no-verified-results state over introducing frontend secrets or unverified media.