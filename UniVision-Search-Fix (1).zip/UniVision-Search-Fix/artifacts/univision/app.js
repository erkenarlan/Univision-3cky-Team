
let all=[],visible=[],current=null,mode='signup',selectedSection='university';
let dataStatusMeta=null;
const searchStatus=document.getElementById('searchStatus'),clearSearch=document.getElementById('clearSearch');
const analysisLoader=document.getElementById('analysisLoader'),analysisTitle=document.getElementById('analysisTitle'),analysisSub=document.getElementById('analysisSub');
let analysisTimer=null,analysisStartedAt=0,mediaRequestId=0;
function setAnalysisStage(stage,progress){document.querySelectorAll('.analysis-stages .stage').forEach(x=>{x.classList.toggle('active',x.dataset.stage===stage);x.classList.toggle('done',['source','place','photo','verify'].includes(x.dataset.stage) && progress>=({'source':20,'place':40,'photo':65,'verify':85}[x.dataset.stage]||0));});const bar=document.getElementById('analysisProgress');if(bar)bar.style.width=Math.max(5,Math.min(100,progress))+'%';}
function showAnalysis(title=I18N[lang]?.analysisTitle||'Analyzing university',sub=I18N[lang]?.analysisSub||'Finding verified materials and checking sources'){analysisTitle.textContent=title;analysisSub.textContent=sub;analysisLoader.hidden=false;analysisStartedAt=performance.now();setAnalysisStage('source',12);clearTimeout(analysisTimer);}
function hideAnalysis(){analysisLoader.hidden=true;clearTimeout(analysisTimer);setAnalysisStage('done',100);}
function cycleAnalysis(type){
  const keys={campus:'analysisBySectionCampus',library:'analysisBySectionLibrary',coworking:'analysisBySectionCoworking',dorm:'analysisBySectionDorm',sports:'analysisBySectionSports',labs:'analysisBySectionLabs',studentlife:'analysisBySectionStudentlife'};
  showAnalysis(tr(keys[type]||'analysisTitle'),tr('analysisFlow'));
}

const list=document.getElementById('list'),filter=document.getElementById('filter'),q=document.getElementById('q'),suggest=document.getElementById('suggest');
const searchIcon=document.querySelector('.search-icon');
if(searchIcon && searchIcon.tagName!=='BUTTON'){
  const searchButton=document.createElement('button');
  searchButton.id='searchButton';
  searchButton.type='button';
  searchButton.className='search-icon';
  searchButton.setAttribute('aria-label','Search university');
  searchButton.title='Search university';
  searchButton.style.border='0';
  searchButton.style.background='transparent';
  searchButton.style.cursor='pointer';
  searchButton.innerHTML=searchIcon.innerHTML;
  searchIcon.replaceWith(searchButton);
}
const DATA_URLS=[
  'https://raw.githubusercontent.com/CheekyRishi/2026-qs-world-university-eda/main/2026%20QS%20World%20University%20Rankings.csv',
  'https://raw.githubusercontent.com/naagrace/QS-World-University-Rankings-Analysis/main/2026%20QS%20World%20University%20Rankings.csv'
];
let KZ_UNIVERSITIES=[
['L.N. Gumilyov Eurasian National University','Astana','Л.Н. Гумилев атындағы Еуразия ұлттық университеті','Евразийский национальный университет имени Л.Н. Гумилева','ENU'],
['Kazakh National University of Arts','Astana','Қазақ ұлттық өнер университеті','Казахский национальный университет искусств','KazNUI'],
['Kazakh National Academy of Choreography','Astana','Қазақ ұлттық хореография академиясы','Казахская национальная академия хореографии','KazNAC'],
['S. Seifullin Kazakh Agrotechnical University','Astana','С. Сейфуллин атындағы Қазақ агротехникалық зерттеу университеті','Казахский агротехнический исследовательский университет имени С. Сейфуллина','KazATU'],
['Astana Medical University','Astana','Астана медицина университеті','Медицинский университет Астана','AMU'],
['Maqsut Narikbayev University','Astana','Мақсұт Нәрікбаев университеті','Университет имени М. Нарикбаева','MNU'],
['Astana IT University','Astana','Astana IT University','Astana IT University','AITU'],
['Al-Farabi Kazakh National University','Almaty','Әл-Фараби атындағы Қазақ ұлттық университеті','Казахский национальный университет имени аль-Фараби','KazNU'],
['Abai Kazakh National Pedagogical University','Almaty','Абай атындағы Қазақ ұлттық педагогикалық университеті','Казахский национальный педагогический университет имени Абая','Abai University'],
['Satbayev University','Almaty','Қ.И. Сәтбаев атындағы Қазақ ұлттық техникалық зерттеу университеті','Казахский национальный исследовательский технический университет имени К.И. Сатпаева','Satbayev University'],
['Kazakh National Agrarian Research University','Almaty','Қазақ ұлттық аграрлық зерттеу университеті','Казахский национальный аграрный исследовательский университет','KazNARU'],
['S. Asfendiyarov Kazakh National Medical University','Almaty','С.Ж. Асфендияров атындағы Қазақ ұлттық медицина университеті','Казахский национальный медицинский университет имени С.Д. Асфендиярова','KazNMU'],
['Kurmangazy Kazakh National Conservatory','Almaty','Құрманғазы атындағы Қазақ ұлттық консерваториясы','Казахская национальная консерватория имени Курмангазы','Kurmangazy Conservatory'],
['KIMEP University','Almaty','KIMEP University','KIMEP University','KIMEP'],
['Kazakh-British Technical University','Almaty','Қазақстан-Британ техникалық университеті','Казахстанско-Британский технический университет','KBTU'],
['SDU University','Almaty region','SDU University','SDU University','SDU'],
['Narxoz University','Almaty','Narxoz University','Университет Нархоз','Narxoz'],
['M. Auezov South Kazakhstan University','Shymkent','М. Әуезов атындағы Оңтүстік Қазақстан университеті','Южно-Казахстанский университет имени М. Ауэзова','Auezov University'],
['K. Zhubanov Aktobe Regional University','Aktobe','Қ. Жұбанов атындағы Ақтөбе өңірлік университеті','Актюбинский региональный университет имени К. Жубанова','Zhubanov University'],
['A. Saginov Karaganda Technical University','Karaganda','Әбілқас Сағынов атындағы Қарағанды техникалық университеті','Карагандинский технический университет имени Абылкаса Сагинова','KarTU'],
['E. Buketov Karaganda University','Karaganda','Е.А. Бөкетов атындағы Қарағанды университеті','Карагандинский университет имени Е.А. Букетова','Buketov University'],
['Karaganda Medical University','Karaganda','Қарағанды медицина университеті','Медицинский университет Караганды','QMU'],
['Toraighyrov University','Pavlodar','Торайғыров университеті','Торайгыров университет','Toraighyrov'],
['M. Kozybayev North Kazakhstan University','Petropavlovsk','М. Қозыбаев атындағы Солтүстік Қазақстан университеті','Северо-Казахстанский университет имени М. Козыбаева','Kozybayev University'],
['D. Serikbayev East Kazakhstan Technical University','Ust-Kamenogorsk','Д. Серікбаев атындағы Шығыс Қазақстан техникалық университеті','Восточно-Казахстанский технический университет имени Д. Серикбаева','EKTU'],
['S. Amanzholov East Kazakhstan University','Ust-Kamenogorsk','С. Аманжолов атындағы Шығыс Қазақстан университеті','Восточно-Казахстанский университет имени С. Аманжолова','Amanzholov University'],
['Sh. Yessenov Caspian University of Technology and Engineering','Aktau','Ш. Есенов атындағы Каспий технологиялар және инжиниринг университеті','Каспийский университет технологий и инжиниринга имени Ш. Есенова','Yessenov University'],
['M. Dulaty Taraz Regional University','Taraz','М.Х. Дулати атындағы Тараз өңірлік университеті','Таразский региональный университет имени М.Х. Дулати','Dulaty University'],
['Sh. Ualikhanov Kokshetau University','Kokshetau','Ш. Уәлиханов атындағы Көкшетау университеті','Кокшетауский университет имени Ш. Уалиханова','Ualikhanov University'],
['Khoja Akhmet Yassawi International Kazakh-Turkish University','Turkistan','Қожа Ахмет Ясауи атындағы Халықаралық қазақ-түрік университеті','Международный казахско-турецкий университет имени Ходжи Ахмеда Ясави','Yassawi University'],
['Esil University','Astana','Esil University','Esil University','Esil'],
['Turan-Astana University','Astana','Тұран-Астана университеті','Университет «Туран-Астана»','Turan Astana'],
['Eurasian Humanities Institute','Astana','А.К. Құсайынов атындағы Еуразия гуманитарлық институты','Евразийский гуманитарный институт имени А.К. Кусаинова','EAGI'],
['International University of Astana','Astana','Астана халықаралық университеті','Международный университет Астана','AIU'],
['Kazakh University of Technology and Business','Astana','Қазақ технология және бизнес университеті','Казахский университет технологии и бизнеса','KUTB'],
['Academy of Physical Culture and Mass Sports','Astana','Дене шынықтыру және бұқаралық спорт академиясы','Академия физической культуры и массового спорта','APCMS'],
['Nazarbayev University','Astana','Назарбаев Университеті','Назарбаев Университет','NU'],
['Almaty University of Power Engineering and Telecommunications','Almaty','Ғ. Дәукеев атындағы Алматы энергетика және байланыс университеті','Алматинский университет энергетики и связи имени Г. Даукеева','AUPET'],
['Almaty Technological University','Almaty','Алматы технологиялық университеті','Алматинский технологический университет','ATU'],
['Almaty Management University','Almaty','Алматы Менеджмент Университеті','Алматы Менеджмент Университет','AlmaU'],
['Kazakh Academy of Sport and Tourism','Almaty','Қазақ спорт және туризм академиясы','Казахская академия спорта и туризма','KazAST'],
['International Information Technology University','Almaty','Халықаралық ақпараттық технологиялар университеті','Международный университет информационных технологий','IITU'],
['Abai Kazakh National Pedagogical University','Almaty','Абай атындағы Қазақ ұлттық педагогикалық университеті','Казахский национальный педагогический университет имени Абая','Abai'],
['Kazakh National Women’s Teacher Training University','Almaty','Қазақ ұлттық қыздар педагогикалық университеті','Казахский национальный женский педагогический университет','QyzPU'],
['Kazakh Academy of Arts named after T. Zhurgenov','Almaty','Т. Жүргенов атындағы Қазақ ұлттық өнер академиясы','Казахская национальная академия искусств имени Т. Жургенова','KazNAA'],
['Kainar Academy','Almaty','Қайнар академиясы','Академия «Кайнар»','Kainar'],
['Kazakh-Russian Medical University','Almaty','Қазақстан-Ресей медицина университеті','Казахстанско-Российский медицинский университет','KRMU'],
['Turan University','Almaty','Тұран университеті','Университет «Туран»','Turan'],
['Academy of Logistics and Transport','Almaty','Логистика және көлік академиясы','Академия логистики и транспорта','ALT'],
['Kazakh University of International Relations and World Languages named after Abylai Khan','Almaty','Абылай хан атындағы Қазақ халықаралық қатынастар және әлем тілдері университеті','Казахский университет международных отношений и мировых языков имени Абылай хана','Ablai Khan'],
['Nurmubarak Egyptian University of Islamic Culture','Almaty','Нұр-Мүбарак Египет ислам мәдениеті университеті','Египетский университет исламской культуры Нур-Мубарак','Nur-Mubarak'],
['Kazakh Automobile and Road Institute named after L. Goncharov','Almaty','Л.Б. Гончаров атындағы Қазақ автомобиль-жол институты','Казахский автомобильно-дорожный институт имени Л.Б. Гончарова','KazADI'],
['University of International Business named after K. Sagadiev','Almaty','К. Сағадиев атындағы Халықаралық бизнес университеті','Университет международного бизнеса имени К. Сагадиева','UIB'],
['Kazakh-German University','Almaty','Қазақстан-Неміс университеті','Казахстанско-Немецкий университет','DKU'],
['Kazakhstan University of Railways','Almaty','Қазақстан жол қатынастары университеті','Казахский университет путей сообщения','KUPS'],
['De Montfort University Kazakhstan','Almaty','De Montfort University Kazakhstan','De Montfort University Kazakhstan','DMUK'],
['International Engineering and Technology University','Almaty','Халықаралық инженерлік-технологиялық университеті','Международный инженерно-технологический университет','IETU'],
['South Kazakhstan Medical Academy','Shymkent','Оңтүстік Қазақстан медицина академиясы','Южно-Казахстанская медицинская академия','SKMA'],
['South Kazakhstan State Pedagogical University','Shymkent','Оңтүстік Қазақстан мемлекеттік педагогикалық университеті','Южно-Казахстанский государственный педагогический университет','SKSPU'],
['Miras University','Shymkent','Мирас университеті','Университет «Мирас»','Miras'],
['Shymkent University','Shymkent','Шымкент университеті','Шымкентский университет','Shymkent Uni'],
['Central Asian Innovation University','Shymkent','Орталық Азия инновациялық университеті','Центрально-Азиатский инновационный университет','CAIU'],
['Tashenev University','Shymkent','Ж. Тәшенев атындағы университет','Университет имени Ж. Ташенева','Tashenev'],
['A. Myrzakhmetov Kokshetau University','Kokshetau','А. Мырзахметов атындағы Көкшетау университеті','Кокшетауский университет имени А. Мырзахметова','KSU'],
['K. Zhubanov Aktobe Regional University','Aktobe','Қ. Жұбанов атындағы Ақтөбе өңірлік университеті','Актюбинский региональный университет имени К. Жубанова','Zhubanov'],
['West Kazakhstan Marat Ospanov Medical University','Aktobe','М. Оспанов атындағы Батыс Қазақстан медицина университеті','Западно-Казахстанский медицинский университет имени М. Оспанова','WKMU'],
['S. Baishev Aktobe University','Aktobe','С. Бәйішев атындағы Ақтөбе университеті','Актюбинский университет имени С. Баишева','Baishev'],
['Kazakh-Russian International University','Aktobe','Қазақ-Ресей халықаралық университеті','Казахско-Русский международный университет','KRIU'],
['Suleyman Demirel University','Kaskelen','Сүлейман Демирел атындағы университет','Университет имени Сулеймана Демиреля','SDU'],
['Atyrau University of Oil and Gas named after S. Utebayev','Atyrau','С. Өтебаев атындағы Атырау мұнай және газ университеті','Атырауский университет нефти и газа имени С. Утебаева','Atyrau Oil'],
['Kh. Dosmukhamedov Atyrau University','Atyrau','Х. Досмұхамедов атындағы Атырау университеті','Атырауский университет имени Х. Досмухамедова','ASU'],
['Atyrau Institute of Engineering and Humanities','Atyrau','Атырау инженерлік-гуманитарлық институты','Атырауский инженерно-гуманитарный институт','AIGI'],
['Zhangir Khan West Kazakhstan Agrarian-Technical University','Uralsk','Жәңгір хан атындағы Батыс Қазақстан аграрлық-техникалық университеті','Западно-Казахстанский аграрно-технический университет имени Жангир хана','ZKATU'],
['M. Utemisov West Kazakhstan University','Uralsk','М. Өтемісов атындағы Батыс Қазақстан университеті','Западно-Казахстанский университет имени М. Утемисова','WKSU'],
['West Kazakhstan Innovation and Technology University','Uralsk','Батыс Қазақстан инновациялық-технологиялық университеті','Западно-Казахстанский инновационно-технологический университет','WKITU'],
['Kazakhstan University of Innovation and Telecommunication Systems','Uralsk','Қазақстан инновациялық және телекоммуникациялық жүйелер университеті','Казахстанский университет инновационных и телекоммуникационных систем','KazIITU'],
['International Taraz Innovative University','Taraz','Халықаралық Тараз инновациялық университеті','Международный Таразский инновационный университет','ITU Taraz'],
['Karaganda Industrial University','Temirtau','Қарағанды индустриялық университеті','Карагандинский индустриальный университет','KarIU'],
['Karaganda Economic University of Kazpotrebsoyuz','Karaganda','Қазтұтынуодағы Қарағанды экономикалық университеті','Карагандинский экономический университет Казпотребсоюза','KEUK'],
['Bolashaq Academy','Karaganda','Bolashaq академиясы','Академия «Bolashaq»','Bolashaq'],
['Central Kazakhstan Academy','Karaganda','Орталық Қазақстан академиясы','Центрально-Казахстанская академия','CKA'],
['Rudny Industrial University','Rudny','Рудный индустриялық университеті','Рудненский индустриальный университет','RIU'],
['M. Dulatov Kostanay Engineering and Economics University','Kostanay','М. Дулатов атындағы Қостанай инженерлік-экономикалық университеті','Костанайский инженерно-экономический университет имени М. Дулатова','KINEU'],
['A. Baitursynov Kostanay Regional University','Kostanay','А. Байтұрсынов атындағы Қостанай өңірлік университеті','Костанайский региональный университет имени А. Байтурсынова','KRU'],
['I. Altynsarin Arkalyk Pedagogical Institute','Arkalyk','Ы. Алтынсарин атындағы Арқалық педагогикалық институты','Аркалыкский педагогический институт имени И. Алтынсарина','API'],
['Zulkharnay Aldamzhar Kostanay Social and Technical University','Kostanay','Зұлқарнай Алдамжар атындағы Қостанай әлеуметтік-техникалық университеті','Костанайский социально-технический университет имени академика Зулхарнай Алдамжар','KSTU'],
['Korkyt Ata Kyzylorda University','Kyzylorda','Қорқыт Ата атындағы Қызылорда университеті','Кызылординский университет имени Коркыт Ата','Korkyt Ata'],
['Bolashak Kyzylorda University','Kyzylorda','Қызылорда «Болашақ» университеті','Кызылординский университет «Болашак»','Bolashak Kyzylorda'],
['Kyzylorda Institute of Technology and Service','Kyzylorda','Қызылорда технология және сервис институты','Кызылординский институт технологии и сервиса','KITS'],
['Pavlodar Pedagogical University','Pavlodar','Павлодар педагогикалық университеті','Павлодарский педагогический университет','PPU'],
['Innovative Eurasian University','Pavlodar','Инновациялық Еуразия университеті','Инновационный Евразийский университет','InEU'],
['K. Satpayev Ekibastuz Engineering and Technical Institute','Ekibastuz','Қ. Сәтбаев атындағы Екібастұз инженерлік-техникалық институты','Екибастузский инженерно-технический институт имени К.И. Сатпаева','EITI'],
['Kazakhstan-American Free University','Ust-Kamenogorsk','Қазақстан-Америка еркін университеті','Казахстанско-Американский свободный университет','KAFU'],
['International University of Tourism and Hospitality','Turkistan','Халықаралық туризм және меймандостық университеті','Международный университет туризма и гостеприимства','IUTH'],
['Alikhan Bokeikhan University','Semey','Alikhan Bokeikhan University','Alikhan Bokeikhan University','ABU'],
['Semey Medical University','Semey','Семей медицина университеті','Медицинский университет Семей','SMU'],
['Shakarim University of Semey','Semey','Семей қаласының Шәкәрім университеті','Университет имени Шакарима города Семей','Shakarim'],
['Abylkas Saginov Karaganda Technical University','Karaganda','Әбілқас Сағынов атындағы Қарағанды техникалық университеті','Карагандинский технический университет имени Абылкаса Сагинова','KarTU'],
['E. A. Buketov Karaganda University','Karaganda','Е.А. Бөкетов атындағы Қарағанды университеті','Карагандинский университет имени Е.А. Букетова','Buketov'],
['M. Kh. Dulaty Taraz Regional University','Taraz','М.Х. Дулати атындағы Тараз өңірлік университеті','Таразский региональный университет имени М.Х. Дулати','Dulaty'],
['Sh. Ualikhanov Kokshetau University','Kokshetau','Ш. Уәлиханов атындағы Көкшетау университеті','Кокшетауский университет имени Ш. Уалиханова','Ualikhanov'],
['Khoja Akhmet Yassawi International Kazakh-Turkish University','Turkistan','Қожа Ахмет Ясауи атындағы Халықаралық қазақ-түрік университеті','Международный казахско-турецкий университет имени Ходжи Ахмеда Ясави','Yassawi'],
['M. Kozybayev North Kazakhstan University','Petropavlovsk','М. Қозыбаев атындағы Солтүстік Қазақстан университеті','Северо-Казахстанский университет имени М. Козыбаева','Kozybayev'],
['D. Serikbayev East Kazakhstan Technical University','Ust-Kamenogorsk','Д. Серікбаев атындағы Шығыс Қазақстан техникалық университеті','Восточно-Казахстанский технический университет имени Д. Серикбаева','EKTU'],
['S. Amanzholov East Kazakhstan University','Ust-Kamenogorsk','С. Аманжолов атындағы Шығыс Қазақстан университеті','Восточно-Казахстанский университет имени С. Аманжолова','Amanzholov'],
['Sh. Yessenov Caspian University of Technology and Engineering','Aktau','Ш. Есенов атындағы Каспий технологиялар және инжиниринг университеті','Каспийский университет технологий и инжиниринга имени Ш. Есенова','Yessenov'],
['M. Auezov South Kazakhstan University','Shymkent','М. Әуезов атындағы Оңтүстік Қазақстан университеті','Южно-Казахстанский университет имени М. Ауэзова','Auezov'],
['Toraighyrov University','Pavlodar','Торайғыров университеті','Торайгыров университет','Toraighyrov'],
['A. Saginov Karaganda Technical University','Karaganda','Әбілқас Сағынов атындағы Қарағанды техникалық университеті','Карагандинский технический университет имени Абылкаса Сагинова','KarTU'],
['Karaganda Medical University','Karaganda','Қарағанды медицина университеті','Медицинский университет Караганды','QMU'],
['M. Kozybayev North Kazakhstan University','Petropavlovsk','М. Қозыбаев атындағы Солтүстік Қазақстан университеті','Северо-Казахстанский университет имени М. Козыбаева','Kozybayev'],
['S. Seifullin Kazakh Agrotechnical Research University','Astana','С. Сейфуллин атындағы Қазақ агротехникалық зерттеу университеті','Казахский агротехнический исследовательский университет имени С. Сейфуллина','KazATU'],
['Maqsut Narikbayev University','Astana','Мақсұт Нәрікбаев университеті','Университет имени М. Нарикбаева','MNU'],
['Astana Medical University','Astana','Астана медицина университеті','Медицинский университет Астана','AMU'],
['KIMEP University','Almaty','KIMEP University','Университет КИМЭП','KIMEP'],
['Narxoz University','Almaty','Narxoz University','Университет Нархоз','Narxoz'],
['SDU University','Kaskelen','SDU University','Университет имени Сулеймана Демиреля','SDU'],
['Satbayev University','Almaty','Қ.И. Сәтбаев атындағы Қазақ ұлттық техникалық зерттеу университеті','Казахский национальный исследовательский технический университет имени К.И. Сатпаева','Satbayev'],
['Al-Farabi Kazakh National University','Almaty','Әл-Фараби атындағы Қазақ ұлттық университеті','Казахский национальный университет имени аль-Фараби','KazNU']
].map(x=>({name:x[0],location:x[1],country:'Kazakhstan',kk:x[2],ru:x[3],acronym:x[4],rank:'—',rankNum:99999,kz:true}));
KZ_UNIVERSITIES=KZ_UNIVERSITIES.filter((u,i,a)=>i===a.findIndex(v=>norm(v.name)===norm(u.name)));all=KZ_UNIVERSITIES.slice();visible=all.slice();
const I18N={
ru:{navHome:'Главная',navTop:'Топ 1500',homeExplore:'Исследовать 1500',homeExploreSub:'Университеты со всего мира',homeVisual:'Визуальные профили',homeVisualSub:'Кампус, лаборатории, общежития и жизнь',homeCompare:'Сравнить',homeCompareSub:'Поставь два университета рядом',homeGuide:'Как это работает',homeGuideSub:'Рейтинг, источники и проверка фото',quote:'Правильный университет — это место, где ты уже видишь себя.',quoteSub:'Смотри дальше, чем рейтинг.',compareTitle:'Сравнение университетов',compareSub:'Выбери два университета и сравни их рядом.',compareA:'Университет A',compareB:'Университет B',compareAction:'Сравнить',navProfile:'Профиль',navAbout:'О проекте',login:'Войти',eyebrow:'Визуальный профиль университета',heroTitle:'Узнай свой будущий<br><span>университет.</span>',heroDesc:'Ищи университет или конкретное место внутри него.',startSearch:'Начни с названия университета',searchPlaceholder:'Найди университет…',analysisTitle:'Анализируем университет',analysisSub:'Ищем подтверждённые материалы и проверяем источники',topTitle:'Топ 1500 университетов',topSub:'QS World University Rankings 2026',topSource:'Реальные названия и ранги из открытого набора QS 2026',filter:'Фильтр по названию или стране',rank:'Место',university:'Университет',location:'Город',explore:'Исследуй университет',materials:'Материалы университета',chooseSection:'Выбери раздел — результаты загружаются автоматически.',verify:'Проверяем источник и соответствие объекта. Нерелевантные материалы не показываем.',photos:'Фото',videos:'Видео',aboutTitle:'О UniVision',aboutText:'Авторизация необязательна. Аккаунт нужен только для сохранения профиля и избранных университетов.',footerTitle:'UniVision · Визуальный профиль университета',authCreate:'Создать аккаунт',authText:'Регистрация по email. Для демо аккаунт хранится локально в браузере.',authEmail:'Email',authPass:'Пароль (минимум 6 символов)',authRegister:'Зарегистрироваться',authLoginSwitch:'Уже есть аккаунт? Войти',source:'Источник',author:'Автор',date:'Дата',evidenceHigh:'✓ Источник и объект подтверждены',evidenceMedium:'△ Подтверждение неполное',evidenceLow:'△ Достоверность недостаточна',checkingMatches:'Проверяем совпадения',checkingSub:'Проверяем университет, объект, источник и визуальные дубликаты',emptyMedia:'Не удалось получить материалы',emptyMediaSub:'Источник изображений сейчас не отвечает или соединение прервано.',noVideo:'Точных видео из открытого источника не найдено.',continueVideo:'Можно продолжить поиск по этому университету:',openVideo:'Открыть поиск видео ↗',findingVideo:'Ищем подтверждённые видео…',sourceDescription:'Источник описания ↗',noDescription:'Открытое описание не найдено.',qsUniversity:'— университет из QS World University Rankings 2026.',secCampus:'Кампус',secLibrary:'Библиотека',secCoworking:'Коворкинг / MakerSpace',secDorm:'Общежитие',secSports:'Спорт',secLabs:'Лаборатории',secStudentlife:'Студенческая жизнь',clear:'Очистить поиск',filter:'Фильтр по названию или стране',noData:'Не удалось загрузить данные. Проверьте соединение.',startAnalysis:'Запускаем анализ…',loading:'Загружаем',created:'Автор: 3CKY GOATS TEAM'},
en:{navHome:'Home',navTop:'Top 1500',homeExplore:'Explore 1500',homeExploreSub:'Universities from around the world',homeVisual:'Visual profiles',homeVisualSub:'Campus, labs, dorms and student life',homeCompare:'Compare',homeCompareSub:'Put two universities side by side',homeGuide:'How it works',homeGuideSub:'Ranking, sources and visual verification',quote:'The right university should feel like a place you can see yourself in.',quoteSub:'Explore beyond the rank.',compareTitle:'Compare universities',compareSub:'Choose two universities and compare them side by side.',compareA:'University A',compareB:'University B',compareAction:'Compare',navProfile:'Profile',navAbout:'About',login:'Sign in',eyebrow:'Visual University Profile',heroTitle:'See your future<br><span>university.</span>',heroDesc:'Search for a university or a specific place inside it.',startSearch:'Start with a university name',searchPlaceholder:'Search for a university…',analysisTitle:'Analyzing university',analysisSub:'Finding verified materials and checking sources',topTitle:'Top 1500 Universities',topSub:'QS World University Rankings 2026',topSource:'Real names and ranks from the open QS 2026 dataset',filter:'Filter by university or country',rank:'Rank',university:'University',location:'Location',explore:'Explore university',materials:'University materials',chooseSection:'Choose a section — results load automatically.',verify:'Checking source and object relevance. Irrelevant materials are hidden.',photos:'Photos',videos:'Videos',aboutTitle:'About UniVision',aboutText:'Sign-in is optional. An account is only needed to save profiles and favorites.',footerTitle:'UniVision · University Visual Profile',authCreate:'Create account',authText:'Email registration. For this demo, the account is stored locally in your browser.',authEmail:'Email',authPass:'Password (minimum 6 characters)',authRegister:'Create account',authLoginSwitch:'Already have an account? Sign in',source:'Source',author:'Author',date:'Date',evidenceHigh:'✓ Source and object verified',evidenceMedium:'△ Verification is incomplete',evidenceLow:'△ Reliability is insufficient',checkingMatches:'Checking matches',checkingSub:'Checking the university, object, source and visual duplicates',emptyMedia:'Could not get materials',emptyMediaSub:'The image source is currently unavailable or the connection was interrupted.',noVideo:'No exact videos were found in the open source.',continueVideo:'You can continue searching for this university:',openVideo:'Open video search ↗',findingVideo:'Finding verified videos…',sourceDescription:'Description source ↗',noDescription:'No public description was found.',qsUniversity:'— university from the QS World University Rankings 2026.',secCampus:'Campus',secLibrary:'Library',secCoworking:'Coworking / MakerSpace',secDorm:'Dorm',secSports:'Sports',secLabs:'Labs',secStudentlife:'Student Life',clear:'Clear search',filter:'Filter by university or country',noData:'Could not load data. Check your connection.',startAnalysis:'Starting analysis…',loading:'Loading',created:'Created by 3CKY GOATS TEAM'},
kk:{navHome:'Басты бет',navTop:'Үздік 1500',homeExplore:'1500 университетті зерттеу',homeExploreSub:'Әлем университеттері',homeVisual:'Визуалды профильдер',homeVisualSub:'Кампус, зертхана, жатақхана және студенттік өмір',homeCompare:'Салыстыру',homeCompareSub:'Екі университетті қатар салыстыр',homeGuide:'Қалай жұмыс істейді',homeGuideSub:'Рейтинг, дереккөз және фото тексеруі',quote:'Дұрыс университет — өзіңді болашақта елестете алатын орын.',quoteSub:'Рейтингтен де кеңірек зертте.',compareTitle:'Университеттерді салыстыру',compareSub:'Екі университетті таңдап, қатар салыстырыңыз.',compareA:'A университеті',compareB:'B университеті',compareAction:'Салыстыру',navProfile:'Профиль',navAbout:'Жоба туралы',login:'Кіру',eyebrow:'Университеттің визуалды профилі',heroTitle:'Болашақ<br><span>университетіңді таны.</span>',heroDesc:'Университетті немесе оның ішіндегі нақты орынды іздеңіз.',startSearch:'Университет атауын енгізіңіз',searchPlaceholder:'Университетті іздеу…',analysisTitle:'Университетті талдап жатырмыз',analysisSub:'Расталған материалдарды іздеп, дереккөздерді тексеріп жатырмыз',topTitle:'Үздік 1500 университет',topSub:'QS World University Rankings 2026',topSource:'QS 2026 ашық деректерінен алынған нақты атаулар мен рейтингтер',filter:'Университет немесе ел бойынша сүзу',rank:'Рейтингтегі орны',university:'Университет',location:'Орналасқан жері',explore:'Университетті зерттеу',materials:'Университет материалдары',chooseSection:'Бөлімді таңдаңыз — нәтижелер автоматты түрде жүктеледі.',verify:'Дереккөз бен нысанның сәйкестігін тексереміз. Сәйкес келмейтін материалдар көрсетілмейді.',photos:'Фотосуреттер',videos:'Бейнелер',aboutTitle:'UniVision туралы',aboutText:'Жүйеге кіру міндетті емес. Аккаунт профильдер мен таңдаулы университеттерді сақтау үшін қажет.',footerTitle:'UniVision · Университеттің визуалды профилі',authCreate:'Аккаунт жасау',authText:'Email арқылы тіркелу. Демо нұсқада аккаунт браузерде жергілікті сақталады.',authEmail:'Email',authPass:'Құпиясөз (кемінде 6 таңба)',authRegister:'Аккаунт жасау',authLoginSwitch:'Аккаунтыңыз бар ма? Кіру',source:'Дереккөз',author:'Автор',date:'Күні',evidenceHigh:'✓ Дереккөз бен нысан расталды',evidenceMedium:'△ Растау толық емес',evidenceLow:'△ Сенімділік жеткіліксіз',checkingMatches:'Сәйкестіктерді тексеріп жатырмыз',checkingSub:'Университетті, нысанды, дереккөзді және визуалды қайталануларды тексереміз',emptyMedia:'Материалдарды алу мүмкін болмады',emptyMediaSub:'Сурет дереккөзі қазір жауап бермейді немесе байланыс үзілді.',noVideo:'Ашық дереккөзден дәл сәйкес бейнелер табылмады.',continueVideo:'Бұл университет бойынша іздеуді жалғастыра аласыз:',openVideo:'Бейне іздеуін ашу ↗',findingVideo:'Расталған бейнелерді іздеп жатырмыз…',sourceDescription:'Сипаттама дереккөзі ↗',noDescription:'Ашық сипаттама табылмады.',qsUniversity:'— QS World University Rankings 2026 тізіміндегі университет.',secCampus:'Кампус',secLibrary:'Кітапхана',secCoworking:'Коворкинг / MakerSpace',secDorm:'Жатақхана',secSports:'Спорт нысандары',secLabs:'Зертханалар',secStudentlife:'Студенттік өмір',clear:'Іздеуді тазарту',noData:'Деректерді жүктеу мүмкін болмады. Интернет байланысын тексеріңіз.',startAnalysis:'Талдау басталуда…',loading:'Жүктелуде',created:'Автор: 3CKY GOATS TEAM'}
 };
 I18N.ru.emptyQuery='Введите название университета';
 I18N.en.emptyQuery='Enter a university name';
 I18N.kk.emptyQuery='Университет атауын енгізіңіз';
 I18N.ru.secClassrooms='Аудитории';
 I18N.en.secClassrooms='Classrooms';
 I18N.kk.secClassrooms='Аудиториялар';
 I18N.ru.secCity='Город';
 I18N.en.secCity='City';
 I18N.kk.secCity='Қала';
 I18N.ru.notEnoughPhotos='Недостаточно подтверждённых фотографий';
 I18N.en.notEnoughPhotos='Not enough verified photos found';
 I18N.kk.notEnoughPhotos='Расталған фотосуреттер жеткіліксіз';
const LOCALE_FILES={en:'./locales/en.json',ru:'./locales/ru.json',kk:'./locales/kk.json'};
function tr(key,vars={}){
  const value=I18N[lang]?.[key]??key;
  return String(value).replace(/\{(\w+)\}/g,(_,name)=>vars[name]===undefined?`{${name}}`:String(vars[name]));
}
async function loadLocales(){
  await Promise.all(Object.entries(LOCALE_FILES).map(async([code,url])=>{
    try{
      const response=await fetch(url,{cache:'no-store'});
      if(!response.ok)throw new Error(`Locale ${code} unavailable`);
      Object.assign(I18N[code],await response.json());
    }catch(error){console.warn('Using built-in locale fallback:',code)}
  }));
}
let lang=localStorage.getItem('univision_lang')||'en';
function updateAuthUi(){
  const email=localStorage.getItem('univision_user_email');
  const account=document.getElementById('account');
  if(account)account.textContent=email?email:'';
  const loginButton=document.getElementById('loginBtn');
  if(loginButton)loginButton.textContent=email?tr('profile'):tr('login');
}
function applyLang(){
  document.documentElement.lang=lang==='kk'?'kk':lang;
  document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(I18N[lang]?.[k])el.innerHTML=tr(k)});
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{const k=el.dataset.i18nPlaceholder;if(I18N[lang]?.[k])el.placeholder=tr(k)});
  document.querySelectorAll('[data-i18n-aria]').forEach(el=>{const k=el.dataset.i18nAria;if(I18N[lang]?.[k])el.setAttribute('aria-label',tr(k))});
  const searchButton=document.getElementById('searchButton');
  if(searchButton){searchButton.setAttribute('aria-label',tr('searchUniversity'));searchButton.title=tr('searchUniversity')}
  document.querySelectorAll('.lang').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));
  if(!q.value)searchStatus.textContent=tr('startSearch');
  if(q.value)updateSuggestions();
  const dataStatus=document.getElementById('dataStatus');
  if(dataStatus&&dataStatusMeta)dataStatus.textContent=tr(dataStatusMeta.key,dataStatusMeta.vars);
  render();populateCompare();updateAuthUi();
  if(auth?.classList.contains('show'))renderAuth();
  if(accountModal?.classList.contains('show'))renderAccount();
  if(current){
    document.getElementById('sectionTitle').textContent=tr('materials');
    document.getElementById('mediaTitle').textContent=`${tr('photos')} · ${sectionLabel(selectedSection)}`;
    document.getElementById('verify').textContent=tr('verify');
    cycleAnalysis(selectedSection);
    wikiDescription(current).then(html=>{document.getElementById('pdesc').innerHTML=html});
    loadMedia(selectedSection);
  }
}
document.querySelectorAll('.lang').forEach(b=>b.onclick=()=>{lang=b.dataset.lang;localStorage.setItem('univision_lang',lang);applyLang()});
document.querySelectorAll('.lang').forEach(b=>b.onclick=()=>{lang=b.dataset.lang;localStorage.setItem('univision_lang',lang);applyLang()});

function parseCSV(text){const rows=[];let row=[],cell='',quote=false;for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'){if(quote&&n==='"'){cell+='"';i++}else quote=!quote}else if(c===','&&!quote){row.push(cell);cell=''}else if((c==='\n'||c==='\r')&&!quote){if(c==='\r'&&n==='\n')i++;row.push(cell);cell='';if(row.some(x=>x.trim()))rows.push(row);row=[]}else cell+=c}if(cell||row.length){row.push(cell);rows.push(row)}return rows}

function displayName(u){return lang==='kk'&&u.kk?u.kk:lang==='ru'&&u.ru?u.ru:u.name}
function searchNames(u){
  return [u.name,u.location,u.country,u.kk,u.ru,u.acronym,u.en,
    u.kz?'Kazakhstan Қазақстан Казахстан KZ':''
  ].filter(Boolean).join(' ')
}
function searchKey(s){
  return String(s||'').toLocaleLowerCase().normalize('NFKC')
    .replace(/[’'`´]/g,' ')
    .replace(/[^\p{L}\p{N}\s]/gu,' ')
    .replace(/\s+/g,' ').trim()
}
function render(){document.getElementById('count').textContent=tr('showingCount',{shown:visible.length,total:all.length});list.innerHTML=visible.map(u=>`<div class="row"><div class="rank">${u.kz?'KZ':'#'+esc(u.rank)}</div><div class="uni">${esc(displayName(u))}${u.kz?'<span class="kz-badge">KZ</span>':''}</div><div class="city">${esc(u.location||'—')}</div><button class="open" data-i="${all.indexOf(u)}">${tr('open')}</button></div>`).join('');document.querySelectorAll('.open').forEach(b=>b.onclick=()=>openUni(all[+b.dataset.i]))}
function esc(x){return String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function universityAliases(u){
  const aliases={
    'L.N. Gumilyov Eurasian National University':'ENU|ЛНУ|ЕҰУ|Евразия ұлттық университеті|Гумилев|Гумилёва',
    'Al-Farabi Kazakh National University':'KazNU|КазНУ|ҚазҰУ|ҚазҰУ|Фараби|аль Фараби',
    'Satbayev University':'Satbayev|КазНИТУ|ҚазҰТЗУ|Сәтбаев|Сатпаев',
    'Maqsut Narikbayev University':'MNU|КАЗГЮУ|ҚазГЗУ|Нарикбаев|Нәрікбаев',
    'Astana IT University':'AITU|Астана IT|АИТУ',
    'Nazarbayev University':'NU|Назарбаев Университеті|НУ',
    'KIMEP University':'KIMEP|КИМЭП',
    'Narxoz University':'Narxoz|Нархоз',
    'Suleyman Demirel University':'SDU|СДУ|Демирель',
    'Khoja Akhmet Yassawi International Kazakh-Turkish University':'AYU|Ясауи|Яссауи|ХҚТУ|МКТУ',
    'M. Auezov South Kazakhstan University':'Auezov|Әуезов|Ауэзов|ОҚУ',
    'Abylkas Saginov Karaganda Technical University':'KarTU|ҚарТУ|КарТУ|Сагинов|Сағынов',
    'Karaganda Medical University':'QMU|ҚМУ|КМУ|Медуниверситет Караганды',
    'D. Serikbayev East Kazakhstan Technical University':'EKTU|ШҚТУ|ВКТУ|Серикбаев|Серікбаев',
    'M. Kozybayev North Kazakhstan University':'Kozybayev|Қозыбаев|Козыбаев|СКУ',
    'S. Seifullin Kazakh Agrotechnical Research University':'KazATU|ҚазАТУ|КазАТУ|Сейфуллин|Сейфуллина',
    'S. Amanzholov East Kazakhstan University':'Amanzholov|Аманжолов|Аманжолов университеті',
    'Sh. Yessenov Caspian University of Technology and Engineering':'Yessenov|Есенов|Каспийский университет',
    'Toraighyrov University':'Toraighyrov|Торайғыров|Торайгыров|ПГУ',
    'M. Kh. Dulaty Taraz Regional University':'Dulaty|Дулати|Дулаты|ТарГУ',
    'Sh. Ualikhanov Kokshetau University':'Ualikhanov|Уәлиханов|Уалиханов|КУ им Уалиханова',
    'K. Zhubanov Aktobe Regional University':'Zhubanov|Жұбанов|Жубанов|АРГУ',
    'Kh. Dosmukhamedov Atyrau University':'Dosmukhamedov|Досмұхамедов|Досмухамедов|АСУ',
    'A. Baitursynov Kostanay Regional University':'Baitursynov|Байтұрсынов|Байтурсынов|КРУ',
    'Korkyt Ata Kyzylorda University':'Korkyt Ata|Қорқыт Ата|Коркыт Ата|ҚУ',
    'Semey Medical University':'SMU|СМУ|Медицинский университет Семей|Семей медицина университеті',
    'Shakarim University of Semey':'Shakarim|Шәкәрім|Шакарим|Семей университеті',
    'International University of Astana':'AIU|МУА|Астана халықаралық университеті',
    'Kazakh National University of Arts':'KazNUI|ҚазҰӨУ|КазНУИ',
    'Kazakh National Women’s Teacher Training University':'QyzPU|ҚазҰҚПУ|КазНЖПУ',
    'International Information Technology University':'IITU|МУИТ|ХАТУ',
    'Academy of Logistics and Transport':'ALT|АЛТ|АлТУ',
    'Almaty University of Power Engineering and Telecommunications':'AUPET|АУЭС|Алматы энергетика',
    'Almaty Technological University':'ATU|АТУ|Алматинский технологический',
    'Almaty Management University':'AlmaU|АлмаУ|Алматы Менеджмент',
    'Kazakh Academy of Sport and Tourism':'KazAST|ҚазСТА|КазАСТ',
    'South Kazakhstan Medical Academy':'SKMA|ОҚМА|ЮКМА',
    'South Kazakhstan State Pedagogical University':'SKSPU|ОҚМПУ|ЮКГПУ',
    'Miras University':'Miras|Мирас',
    'Central Asian Innovation University':'CAIU|ОАИУ|ЦАИУ',
    'West Kazakhstan Innovation and Technology University':'WKITU|БҚИТУ|ЗКИТУ',
    'Kazakhstan-American Free University':'KAFU|ҚАЕУ|КАСУ'
  };
  const raw=(aliases[u.name]||'').split('|').filter(Boolean);
  const values=[u.name,u.searchName,u.kk,u.ru,u.acronym,...raw,u.location].filter(Boolean);
  const words=[...new Set(values.flatMap(value=>norm(value).split(' ').filter(word=>word.length>2)))];
  return {
    acronym:raw[0]||u.acronym||'',
    aliases:values,
    words,
    loc:norm(u.location||'')
  };
}
function cleanMeta(value){
  return String(value||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
}
const PHOTO_TERMS={
  campus:['campus','university building','main building','academic building','quad','college building'],
  dorm:['dorm','dormitory','residence hall','student housing','hostel'],
  classrooms:['classroom','lecture hall','auditorium','seminar room','teaching room'],
  library:['library','reading room','book stacks'],
  sports:['sports','gym','stadium','athletics','fitness','football field'],
  labs:['laboratory','laboratories','research lab','science building','lab'],
  studentlife:['student life','students','student center','student union','graduation'],
  city:['city','downtown','street','skyline','neighborhood','urban'],
  coworking:['coworking','maker space','makerspace','innovation hub','workspace']
};
function intentTerms(type){return PHOTO_TERMS[type]||PHOTO_TERMS.campus}
function titleTerms(type){return intentTerms(type).slice(0,4)}
function negativeTerms(type){
  const common=['logo','flag','map','seal','portrait','person'];
  return type==='city'?common.filter(x=>x!=='map'):[...common,'football player','random landscape'];
}
function evidenceText(page,u,type){
  const info=page?.imageinfo?.[0]||{};
  const meta=info.extmetadata||{};
  return [
    page?.title,u?.name,u?.searchName,u?.location,u?.country,
    meta.ObjectName?.value,meta.ImageDescription?.value,meta.Categories?.value,
    meta.Subject?.value
  ].map(cleanMeta).filter(Boolean).join(' ');
}
function titleEvidence(page,u,type){
  const info=page?.imageinfo?.[0]||{};
  const meta=info.extmetadata||{};
  const title=norm(cleanMeta(page?.title));
  const metadata=norm([
    meta.ObjectName?.value,meta.ImageDescription?.value,meta.Categories?.value,
    meta.Subject?.value
  ].map(cleanMeta).filter(Boolean).join(' '));
  const aliases=universityAliases(u).aliases.map(norm).filter(Boolean);
  const terms=intentTerms(type).map(norm);
  return {
    uniTitle:aliases.some(alias=>title.includes(alias)),
    uniMeta:aliases.some(alias=>metadata.includes(alias)),
    sectionHits:terms.filter(term=>title.includes(term)),
    metaSectionHits:terms.filter(term=>metadata.includes(term))
  };
}
function norm(s){return searchKey(s)}
filter.addEventListener('input',()=>{const s=norm(filter.value);visible=!s?all.slice():all.filter(u=>matchesUniversity(u,s));render();});
function matchesUniversity(u,s){const query=norm(s);if(!query)return true;const aliases=universityAliases(u).aliases.map(norm);const hay=aliases.join(' ');if(hay.includes(query))return true;const tokens=query.split(' ').filter(Boolean);return tokens.every(t=>hay.includes(t));}
function editDistance(a,b){const prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const next=[i];for(let j=1;j<=b.length;j++)next[j]=Math.min(next[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));for(let j=0;j<next.length;j++)prev[j]=next[j]}return prev[b.length]}
function typoMatch(u,s){const query=norm(s).split(' ').filter(Boolean),name=norm(u.name||'').split(' ').filter(Boolean);if(!query.length||!name.length)return false;return query.every(token=>name.some(word=>word.includes(token)||((token.length>=5||word.length>=5)&&editDistance(token,word)<=2)))}
const SEARCH_HINTS=[
  {name:'Massachusetts Institute of Technology (MIT)',location:'Cambridge, USA',acronym:'MIT'},
  {name:'Harvard University',location:'Cambridge, USA',acronym:'Harvard'},
  {name:'Stanford University',location:'Stanford, USA',acronym:'Stanford'},
  {name:'University of Oxford',location:'Oxford, UK',acronym:'Oxford'},
  {name:'University of Cambridge',location:'Cambridge, UK',acronym:'Cambridge'},
  {name:'Imperial College London',location:'London, UK',acronym:'Imperial'},
  {name:'ETH Zurich',location:'Zurich, Switzerland',acronym:'ETH'},
  {name:'National University of Singapore',location:'Singapore',acronym:'NUS'},
  {name:'Tsinghua University',location:'Beijing, China',acronym:'Tsinghua'},
  {name:'Nazarbayev University',location:'Astana, Kazakhstan',acronym:'NU'},
  {name:'Al-Farabi Kazakh National University',location:'Almaty, Kazakhstan',acronym:'KazNU'},
  {name:'Satbayev University',location:'Almaty, Kazakhstan',acronym:'Satbayev'}
];
function updateSuggestions(){const raw=q.value.trim(),s=norm(raw);clearSearch.style.display=s?'grid':'none';if(!s){suggest.hidden=true;searchStatus.textContent=tr('startSearch');return;}
  const combined=[...all,...SEARCH_HINTS];
  const seen=new Set();
  const hits=combined.filter(u=>{
    const key=(u.name||'').toLowerCase(); if(seen.has(key))return false; seen.add(key);
    const kzAlias=['kazakhstan','қазақстан','казахстан','kz','kaz'].includes(s);
    return matchesUniversity(u,s)||(kzAlias&&u.kz);
  }).sort((a,b)=>{
  const sa=norm(searchNames(a)),sb=norm(searchNames(b));
  const aKz=['kazakhstan','қазақстан','казахстан','kz'].includes(s)&&a.kz;
  const bKz=['kazakhstan','қазақстан','казахстан','kz'].includes(s)&&b.kz;
  return (aKz?0:bKz?1:sa.startsWith(s)?0:1)-(bKz?0:aKz?1:sb.startsWith(s)?0:1)
}).slice(0,8);
 const correction=!hits.length?all.find(u=>typoMatch(u,raw)):null;
  const correctionLabel=tr('didYouMean');
 const correctionRow=correction?`<div data-correction="${all.indexOf(correction)}"><b>✨ ${correctionLabel}: ${esc(displayName(correction))}</b><span class="suggest-city">${esc(correction.location||'')}</span></div>`:'';
 const remoteLabel=tr('searchThisUniversity');
 const remoteSub=tr('searchScope');
const remoteRow=`<div data-remote-search="1"><b>📸 ${esc(raw)}</b><span class="suggest-city">${remoteLabel} · ${remoteSub}</span></div>`;
 suggest.innerHTML=correctionRow+hits.map((u,i)=>{const idx=all.indexOf(u);const key=idx>=0?`data-i="${idx}"`:`data-hint="${esc(u.name)}"`;return `<div ${key}><b>${esc(displayName(u))}</b><span class="suggest-city">${esc(u.location||'')}</span></div>`}).join('')+remoteRow;
suggest.hidden=false;
 searchStatus.textContent=hits.length?tr('catalogMatches',{count:hits.length}):tr('readyWebSearch');
bindSuggestionClicks();}
async function resolveUniversityOnline(name){
  const clean=String(name||'').trim();
  if(!clean)return null;
  try{
    const url='https://en.wikipedia.org/w/api.php?origin=*&action=query&format=json&generator=search&gsrsearch='+encodeURIComponent(clean+' university')+'&gsrnamespace=0&gsrlimit=5&prop=extracts|info&exintro=1&explaintext=1&inprop=url';
    const r=await fetch(url,{cache:'no-store'}); if(!r.ok)return null;
    const pages=Object.values((await r.json()).query?.pages||{});
    const requestedTokens=norm(clean).split(' ').filter(token=>token.length>2&&!['university','college','institute','school','academy'].includes(token));
    const page=pages.find(candidate=>{
      const title=norm(candidate.title);
      const academicTitle=/\b(university|college|institute|school|academy)\b/i.test(candidate.title);
      const requestedName=requestedTokens.length>0&&requestedTokens.every(token=>title.includes(token));
      return academicTitle&&requestedName;
    });
    if(!page)return null;
    return {name:page.title,searchName:clean,location:'',country:'',kk:page.title,ru:page.title,acronym:'',rank:'—',rankNum:99999,kz:false,custom:true,wikiExtract:page.extract||'',wikiUrl:page.fullurl||('https://en.wikipedia.org/wiki/'+encodeURIComponent(page.title.replaceAll(' ','_')))};
  }catch(e){return null}
}
async function startVisualSearch(raw,section='campus'){
  const name=String(raw||'').trim();
  if(!name){
    q.focus();
    searchStatus.style.display='block';
    searchStatus.textContent=tr('emptyQuery');
    return;
  }
  const query=norm(name);
  const exact=all.find(u=>[u.name,u.acronym,displayName(u)].filter(Boolean).some(value=>norm(value)===query));
  const hinted=SEARCH_HINTS.find(u=>matchesUniversity(u,query));
  let u=exact||hinted;
  if(!u){
    showAnalysis(tr('analysisSearchingSources'),tr('analysisBuildingProfile'));
    u=await resolveUniversityOnline(name);
  }
  u=u||{name,location:'',country:'',kk:name,ru:name,acronym:'',rank:'—',rankNum:99999,kz:false,custom:true,searchName:name};
  u={rank:'—',rankNum:99999,location:'',country:'',kk:u.name,ru:u.name,acronym:'',...u,searchName:u.searchName||name};
  q.value=displayName(u); suggest.hidden=true;
  searchStatus.style.display='none';
  openUni(u,section);
}
function bindSuggestionClicks(){suggest.querySelectorAll('div[data-i]').forEach(x=>x.onclick=()=>{const u=all[Number(x.dataset.i)];if(u)startVisualSearch(displayName(u),'campus')});suggest.querySelectorAll('div[data-hint]').forEach(x=>x.onclick=()=>startVisualSearch(x.dataset.hint,'campus'));suggest.querySelectorAll('div[data-correction]').forEach(x=>x.onclick=()=>{const u=all[Number(x.dataset.correction)];if(u)startVisualSearch(displayName(u),'campus')});const remote=suggest.querySelector('[data-remote-search]');if(remote)remote.onclick=()=>startVisualSearch(q.value.trim(),'campus');}
function submitSearch(){startVisualSearch(q.value.trim(),'campus')}
q.addEventListener('input',updateSuggestions);
q.addEventListener('focus',updateSuggestions);
q.addEventListener('keydown',e=>{if(e.key==='Escape'){suggest.hidden=true;return;}if(e.key==='Enter'){e.preventDefault();submitSearch();}});
document.getElementById('searchButton')?.addEventListener('click',submitSearch);
document.addEventListener('click',e=>{if(!e.target.closest('.search'))suggest.hidden=true;});
function sectionLabel(t){const keys={campus:'sectionCampus',library:'sectionLibrary',coworking:'sectionCoworking',dorm:'sectionDorm',classrooms:'sectionClassrooms',sports:'sectionSports',labs:'sectionLabs',studentlife:'sectionStudentlife',city:'sectionCity',university:'sectionUniversity'};return tr(keys[t]||'sectionUniversity')}
document.querySelectorAll('.profile-section').forEach(b=>b.onclick=()=>{if(!current)return;document.querySelectorAll('.profile-section').forEach(x=>x.classList.toggle('active',x.dataset.type===b.dataset.type));selectedSection=b.dataset.type;searchStatus.textContent=`${tr('loading')}: ${sectionLabel(selectedSection)}`;cycleAnalysis(selectedSection);loadMedia(selectedSection)});

document.addEventListener('click',e=>{if(!e.target.closest('.search'))suggest.hidden=true});clearSearch.onclick=()=>{q.value='';clearSearch.style.display='none';suggest.hidden=true;searchStatus.style.display='block';searchStatus.textContent=tr('startSearch');current=null;hideAnalysis();document.getElementById('profile').classList.remove('show')};
async function wikiDescription(u){
  const fallback=`<b>${esc(u.name)}</b> ${tr('qsUniversity')}`;
  if(u.wikiExtract)return esc(u.wikiExtract)+`<br><br><a href="${esc(u.wikiUrl)}" target="_blank" rel="noopener" style="color:#087a42">${tr('sourceDescription')}</a>`;
  try{
    const title=encodeURIComponent(u.name),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
    const r=await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/'+title,{signal:controller.signal,cache:'no-store'});clearTimeout(timer);
    const wiki=r.ok?await r.json():null;
    if(wiki?.extract)return esc(wiki.extract)+`<br><br><a href="${esc(wiki.content_urls?.desktop?.page||'https://en.wikipedia.org/wiki/'+title)}" target="_blank" rel="noopener" style="color:#087a42">${tr('sourceDescription')}</a>`;
    return `${fallback} ${tr('noDescription')}`;
  }catch(e){return fallback}
}
function populateCompare(){const a=document.getElementById('compareA'),b=document.getElementById('compareB');if(!a||!b)return;const opts=all.slice(0,1500).map((u,i)=>`<option value="${i}">${esc(displayName(u))} · ${u.kz?'KZ':'#'+esc(u.rank)}</option>`).join('');a.innerHTML=`<option value="">${tr('compareChoose')}</option>`+opts;b.innerHTML=`<option value="">${tr('compareChoose')}</option>`+opts;}
function runCompare(){const a=document.getElementById('compareA'),b=document.getElementById('compareB'),r=document.getElementById('compareResult');if(!a||!b||!r||a.value===''||b.value===''){return}const x=all[+a.value],y=all[+b.value];r.hidden=false;r.innerHTML=`<div class="compare-grid"><div><b>${esc(displayName(x))}</b><p>#${esc(x.rank||'—')} · ${esc(x.location||'—')}</p></div><div class="compare-vs">VS</div><div><b>${esc(displayName(y))}</b><p>#${esc(y.rank||'—')} · ${esc(y.location||'—')}</p></div></div>`;}
async function init(){
  // Render the built-in university catalog immediately so search works even when remote QS data is slow/offline.
  all=KZ_UNIVERSITIES.slice();visible=all.slice();render();applyLang();populateCompare();
  const CACHE_KEY='univision_qs_2026_v2';
  const setStatus=(msg,offline=false,meta=null)=>{if(meta)dataStatusMeta=meta;let el=document.getElementById('dataStatus');if(!el){el=document.createElement('div');el.id='dataStatus';el.className='data-status';document.querySelector('.source').appendChild(el)}el.textContent=msg;el.classList.toggle('offline',offline)};
  try{
    let text=localStorage.getItem(CACHE_KEY)||'';
    if(text){setStatus(tr('dataStatusCached'),false,{key:'dataStatusCached',vars:{}});}
    if(!text){
      const controller=new AbortController();
      const totalTimer=setTimeout(()=>controller.abort(),7500);
      try{
        const responses=await Promise.allSettled(DATA_URLS.map(url=>fetch(url,{cache:'no-store',signal:controller.signal}).then(r=>r.ok?r.text():'')));
        const candidate=responses.map(x=>x.status==='fulfilled'?x.value:'').find(x=>x.length>50000);
        if(candidate)text=candidate;
      }finally{clearTimeout(totalTimer)}
    }
    if(!text){try{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),2500);const r=await fetch('qs2026.csv',{cache:'no-store',signal:controller.signal});clearTimeout(timer);if(r.ok)text=await r.text()}catch(_){} }
    if(text){try{localStorage.setItem(CACHE_KEY,text)}catch(_){}
      const rows=parseCSV(text);let header=rows.findIndex(r=>r.some(x=>/institution name|university name|^name$|^institution$/i.test(x.trim()))&&r.some(x=>/country|territory|location/i.test(x)));
      if(header<0)throw Error('header');const h=rows[header].map(x=>x.trim());const ni=h.findIndex(x=>/institution name|university name|^name$|^institution$/i.test(x));const ci=h.findIndex(x=>/country|territory|location/i.test(x));const ri=h.findIndex(x=>/2026 rank|rank|overall rank/i.test(x));
      const qs=rows.slice(header+1).map(r=>({rank:(r[ri]||'').trim(),name:(r[ni]||'').trim(),location:(r[ci]||'').trim()})).filter(u=>u.name&&u.rank&&u.rank!=='—').map(u=>({...u,rankNum:parseInt(String(u.rank).replace(/[^0-9]/g,''))||99999})).sort((a,b)=>a.rankNum-b.rankNum).slice(0,1500);
      const cached=text===localStorage.getItem(CACHE_KEY);
      const statusVars={count:qs.length,cached:cached?' · '+tr('dataStatusCached').split(' · ')[1]:''};
      const qNames=new Set(qs.map(u=>norm(u.name)));all=qs.concat(KZ_UNIVERSITIES.filter(u=>!qNames.has(norm(u.name))));visible=all.slice();render();applyLang();populateCompare();setStatus(tr('dataStatusLoaded',statusVars),false,{key:'dataStatusLoaded',vars:statusVars});return;
    }
    throw Error('data');
  }catch(e){
    all=KZ_UNIVERSITIES.slice();visible=all.slice();render();applyLang();populateCompare();setStatus(tr('dataStatusOffline'),true,{key:'dataStatusOffline',vars:{}});
    document.getElementById('count').textContent=tr('localUniversities',{count:all.length});
  }
}
function scorePhoto(page,u,type){
  const t=norm(evidenceText(page,u,type)),a=universityAliases(u),terms=intentTerms(type).map(norm),neg=negativeTerms(type).map(norm),te=titleEvidence(page,u,type);
  let score=0; let uniStrong=false;
  for(const alias of a.aliases){
    if(alias && t.includes(alias)){score+=18;uniStrong=true;break}
  }
  const matchedWords=a.words.filter(w=>t.includes(w));
  score+=Math.min(matchedWords.length,3)*3;
  const intentHits=terms.filter(x=>t.includes(x));
  score+=Math.min(intentHits.length,3)*6;
  score-=neg.filter(x=>t.includes(x)).length*10;
  if(a.loc&&t.includes(a.loc)&&!uniStrong)score-=8;
  if(te.uniTitle)score+=30;
  else if(te.uniMeta)score+=16;
  if(te.sectionHits.length)score+=25;
  else if(te.metaSectionHits.length)score+=15;
  return {score,uniStrong,intentHits:intentHits.length,matchedWords:matchedWords.length,titleUni:te.uniTitle,metaUni:te.uniMeta,titleSection:te.sectionHits.length>0,metaSection:te.metaSectionHits.length>0};
}
function confidencePhoto(page,u,type){
  const s=scorePhoto(page,u,type);
  let level='low',label=tr('confidenceUnverified');
  if(s.titleUni&&s.titleSection&&s.uniStrong&&s.intentHits>=1&&s.score>=55){level='high';label=tr('confidenceHigh')}
  else if((s.titleUni||s.metaUni)&& (s.titleSection||s.metaSection||s.intentHits>=1) && s.score>=32){level='medium';label=tr('confidenceMedium')}
  return {level,label,score:s.score};
}
function validPhoto(page,u,type){
  const s=scorePhoto(page,u,type);
  // Tiered matching: don't require the university and section to both be in the filename.
  // Wikimedia descriptions/categories often contain the missing evidence.
  const hasUniversity=s.titleUni||s.metaUni||s.uniStrong;
  const hasSection=s.titleSection||s.metaSection||s.intentHits>0;
  if(!hasUniversity||!hasSection)return false;
  if(s.score<28)return false;
  return true;
}
function hashDistance(a,b){let d=0;for(let i=0;i<Math.min(a.length,b.length);i++)if(a[i]!==b[i])d++;return d+Math.abs(a.length-b.length)}
async function perceptualHash(url){
  try{
    const img=new Image();img.crossOrigin='anonymous';img.src=url;
    await new Promise((res,rej)=>{img.onload=res;img.onerror=rej});
    const c=document.createElement('canvas'),ctx=c.getContext('2d',{willReadFrequently:true});
    c.width=16;c.height=16;ctx.drawImage(img,0,0,16,16);
    const data=ctx.getImageData(0,0,16,16).data;let vals=[];
    for(let i=0;i<256;i++){const j=i*4;vals.push((data[j]*.299+data[j+1]*.587+data[j+2]*.114))}
    const avg=vals.reduce((a,b)=>a+b,0)/vals.length;
    return vals.map(v=>v>=avg?'1':'0').join('')
  }catch(e){return null}
}
function dedupeVisual(pages){
  const seen=new Set(),out=[];
  for(const x of pages){
    const i=x.imageinfo?.[0]||{},key=i.sha1||i.url||x.title;
    if(seen.has(key))continue; seen.add(key); out.push(x);
    if(out.length>=9)break;
  }
  return out;
}
async function commonsSearch(query,limit=18){
  const p=new URLSearchParams({action:'query',format:'json',origin:'*',generator:'search',gsrsearch:query,gsrnamespace:'6',gsrlimit:String(limit),prop:'imageinfo',iiprop:'url|extmetadata|sha1|mime|size',iiurlwidth:'1000'});
  const url='https://commons.wikimedia.org/w/api.php?'+p.toString();
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),6500);
  try{
    const r=await fetch(url,{mode:'cors',cache:'no-store',headers:{Accept:'application/json'},signal:controller.signal});
    if(!r.ok)throw new Error('Commons HTTP '+r.status);
    const d=await r.json();
    return Object.values(d.query?.pages||{}).filter(x=>x.imageinfo?.[0]?.url);
  }finally{clearTimeout(timer)}
}
function categoryQuery(u,type){
  const safe=u.name.replace(/[^a-zA-Z0-9]+/g,'_').replace(/^_+|_+$/g,'');
  const term=intentTerms(type)[0];
  return `incategory:${safe} ${term}`;
}
function searchQueries(u,type){
  const terms=titleTerms(type);
  const a=universityAliases(u);
  const names=[u.name,u.searchName].filter(Boolean);
  const q=[];
  // Search both the resolved Wikipedia title and exactly what the user typed.
  // This is important for universities whose official/common name differs from the Wikipedia title.
  for(const name of names){
    for(const term of terms){
      q.push(`intitle:"${name}" ${term}`);
      q.push(`"${name}" ${term}`);
      q.push(`"${name}" university ${term}`);
    }
  }
  if(a.acronym)for(const term of terms)q.push(`intitle:${a.acronym} ${term}`);
  if(a.loc)for(const name of names)q.push(`"${name}" ${a.loc} ${terms[0]}`);
  if(type==='campus')for(const name of names)q.push(`"${name}" main building`);
  // Commons categories are useful when filenames contain no university name.
  for(const name of names)q.push(`incategory:${name.replace(/[^\p{L}\p{N}]+/gu,'_')} ${terms[0]}`);
  return [...new Set(q)].slice(0,18);
}
function beautyScore(page,u,type){
  const i=page.imageinfo?.[0]||{}; const w=Number(i.width||0),h=Number(i.height||0);
  const ratio=h?Math.min(w/h,h/w):0; let score=0;
  if(w>=1800) score+=18; else if(w>=1200) score+=10; else if(w>=800) score+=5;
  if(ratio>=.55) score+=8;
  if(i.thumburl) score+=4;
  const text=evidenceText(page,u,type);
  if(type==='campus' && /(campus|university building|main building|academic building|quad)/.test(text)) score+=18;
  if(type==='library' && /library/.test(text)) score+=12;
  return score;
}
async function searchVideos(u,type){
  const terms=titleTerms(type);
  let raw=[];
  for(const term of terms){
    try{ raw.push(...await commonsSearch(`intitle:"${u.name}" intitle:${term}`,20)); }catch(e){}
  }
  const unique=new Map();
  for(const x of raw){
    const i=x.imageinfo?.[0]; if(!i) continue;
    const mime=String(i.mime||'').toLowerCase();
    const url=String(i.url||'').toLowerCase();
    if(!mime.includes('video') && !/\.(mp4|webm|ogv|mov)(\?|$)/.test(url)) continue;
    const s=scorePhoto(x,u,type);
    if(!s.titleUni || !s.titleSection) continue;
    const c=confidencePhoto(x,u,type);
    const key=i.sha1||i.url; unique.set(key,{...x,_score:s.score,_confidence:c});
  }
  return [...unique.values()].sort((a,b)=>b._score-a._score).slice(0,6);
}

function noVerifiedPhotoMarkup(u,type,includeRetry=true){
  const query=encodeURIComponent(`${u.name} ${sectionLabel(type)}`);
  const retry=includeRetry?`<br><button class="retry-btn" type="button" onclick="loadMedia('${esc(type)}')">${tr('searchAgain')}</button>`:'';
  return `<div class="empty-media"><b>${tr('notEnoughPhotos')}</b><br><small>${tr('emptyMediaSub')}</small><br><a class="video-search-link" href="https://commons.wikimedia.org/w/index.php?search=${query}&title=Special:MediaSearch&type=image" target="_blank" rel="noopener">${tr('continueSourceSearch')}</a>${retry}</div>`;
}

async function searchPhotos(u,type='campus'){
  const requestId=++mediaRequestId;
  const ph=document.getElementById('photos'),vid=document.getElementById('videos');ph.hidden=false;vid.hidden=true;
  cycleAnalysis(type);ph.innerHTML=`<div class="empty-media">${tr('loadingMedia')}</div>`;
  const queries=searchQueries(u,type).slice(0,6);
  try{
    showAnalysis(tr('analysisSearchingSources'),tr('analysisFindingPhotos'));setAnalysisStage('place',40);
    const guard=new Promise((_,reject)=>setTimeout(()=>reject(new Error('photo-timeout')),8200));
    const batch=Promise.allSettled(queries.map(q=>commonsSearch(q,16)));
    const results=await Promise.race([batch,guard]);
    if(requestId!==mediaRequestId)return;const raw=results.flatMap(r=>r.status==='fulfilled'?r.value:[]);
    if(!raw.length)throw new Error('image-source-unavailable');
    showAnalysis(tr('analysisCheckingMatch'),tr('analysisRemovingDuplicates'));setAnalysisStage('photo',65);
    const unique=new Map();
    for(const x of raw){const i=x.imageinfo?.[0]||{},key=i.sha1||i.url||x.title;if(key&&!unique.has(key))unique.set(key,x)}
    let scored=[...unique.values()].map(x=>{const s=scorePhoto(x,u,type),c=confidencePhoto(x,u,type);return {...x,_score:s.score+beautyScore(x,u,type),_evidence:s,_confidence:c}})
      .filter(x=>validPhoto(x,u,type) && x._confidence.level!=='low')
      .sort((a,b)=>b._score-a._score);
    const out=dedupeVisual(scored);
    showAnalysis(tr('analysisCategorizingPhotos'),tr('analysisBuildingProfile'));setAnalysisStage('verify',82);
    if(requestId!==mediaRequestId)return;
    if(!out.length){hideAnalysis();ph.innerHTML=noVerifiedPhotoMarkup(u,type);document.getElementById('verify').textContent=tr('notEnoughPhotos');return}
    const high=out.filter(x=>x._confidence.level==='high').length,medium=out.length-high;
    document.getElementById('verify').textContent=tr('verifiedMaterials',{count:out.length,high,medium});
    const location=u.location||u.country||'Kazakhstan';
    ph.innerHTML=out.map(x=>{
      const i=x.imageinfo[0],src='https://commons.wikimedia.org/wiki/'+encodeURIComponent(x.title.replaceAll(' ','_')),m=i.extmetadata||{},author=cleanMeta(m.Artist?.value),date=cleanMeta(m.DateTimeOriginal?.value||m.DateTime?.value),desc=cleanMeta(m.ImageDescription?.value),c=x._confidence;
      const badgeClass=c.level==='high'?'confidence-high':'confidence-medium';
      const place=`${sectionLabel(type)} · ${location}`;
      return `<article class="photo"><img src="${i.thumburl||i.url}" loading="lazy" alt="${esc(u.name)} — ${esc(place)}"><div class="photo-body"><b>${esc(displayName(u))}</b><div class="section-note"><strong>📍 ${esc(place)}</strong></div><div class="section-note">${esc(x.title.replace(/^File:/,''))}</div>${desc?`<div class="section-note">${esc(desc.slice(0,150))}</div>`:''}<br>${author?`<small>${tr('author')}: ${esc(author)}</small><br>`:''}${date?`<small>${tr('date')}: ${esc(date)}</small><br>`:''}<span class="badge ${badgeClass}">${esc(c.label)}</span><div class="evidence">${c.level==='high'?tr('evidenceHigh'):tr('evidenceMedium')}</div><br><a href="${src}" target="_blank" rel="noopener">${tr('source')} ↗</a></div></article>`}).join('');
    hideAnalysis();
  }catch(e){
    hideAnalysis();
    ph.innerHTML=noVerifiedPhotoMarkup(u,type);
    document.getElementById('verify').textContent=tr('notEnoughPhotos');
  }
}
async function loadMedia(type){if(!current)return;document.getElementById('sectionTitle').textContent=sectionLabel(type);document.getElementById('mediaTitle').textContent=`${tr('photos')} · ${sectionLabel(type)}`;await searchPhotos(current,type);}
async function openUni(u,type='campus'){current=u;selectedSection=type;cycleAnalysis(type);document.querySelectorAll('.profile-section').forEach(x=>x.classList.toggle('active',x.dataset.type===type));searchStatus.style.display='none';document.getElementById('profile').classList.add('show');document.getElementById('pname').innerHTML=esc(displayName(u))+` <span class="rank-pill">${u.kz?'KZ':`QS #${esc(u.rank)}`}</span>`;document.getElementById('pcity').textContent=u.location||tr('locationFallback');document.getElementById('pdesc').innerHTML=`<span style="color:#6f7e77">${tr('analysisBuildingProfile')}</span>`;const descPromise=wikiDescription(u);const mediaPromise=loadMedia(type);Promise.resolve(descPromise).then(html=>{document.getElementById('pdesc').innerHTML=html});await mediaPromise;document.getElementById('profile').scrollIntoView({behavior:'smooth'})}
document.querySelectorAll('.media-tab').forEach(b=>b.onclick=async()=>{
  document.querySelectorAll('.media-tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');
  if(b.dataset.media==='videos'){
    document.getElementById('photos').hidden=true;const v=document.getElementById('videos');v.hidden=false;v.innerHTML=`<div class="empty-media">${tr('findingVideo')}</div>`;
    try{
      const out=await searchVideos(current,selectedSection);
      if(!out.length){
        const q=encodeURIComponent(`${current.name} ${sectionLabel(selectedSection)} campus university`);
        v.innerHTML=`<div class="empty-media"><b>${tr('noVideo')}</b><br><small>${tr('continueVideo')}</small><br><a class="video-search-link" href="https://www.youtube.com/results?search_query=${q}" target="_blank" rel="noopener">${tr('openVideo')}</a></div>`;return;
      }
      v.innerHTML=out.map(x=>{const i=x.imageinfo[0],src='https://commons.wikimedia.org/wiki/'+encodeURIComponent(x.title.replaceAll(' ','_')),c=x._confidence;return `<article class="video-card"><video controls preload="metadata" src="${i.url}"></video><div class="photo-body"><b>${esc(x.title.replace(/^File:/,''))}</b><br><span class="badge ${c.level==='high'?'confidence-high':c.level==='medium'?'confidence-medium':'confidence-low'}">${esc(c.label)}</span><br><a href="${src}" target="_blank" rel="noopener">${tr('source')} ↗</a></div></article>`}).join('');
    }catch(e){v.innerHTML=`<div class="empty-media"><b>${tr('videoUnavailable')}</b><br><small>${tr('tryLater')}</small></div>`}
  }else{document.getElementById('videos').hidden=true;document.getElementById('photos').hidden=false;await searchPhotos(current,selectedSection)}
});
const auth=document.getElementById('auth'),authTitle=document.getElementById('authTitle'),authText=document.getElementById('authText'),authSubmit=document.getElementById('authSubmit'),authSwitch=document.getElementById('switch'),authStatus=document.getElementById('authStatus');
const accountModal=document.getElementById('accountModal'),accountEmail=document.getElementById('accountEmail');
function renderAuth(){
  const signup=mode==='signup';
  authTitle.textContent=tr(signup?'authCreate':'authLogin');
  authText.textContent=tr(signup?'authText':'authLoginText');
  authSubmit.textContent=tr(signup?'authRegister':'authSubmitLogin');
  authSwitch.textContent=tr(signup?'authLoginSwitch':'authRegisterSwitch');
  authStatus.textContent='';
}
function openAuth(nextMode='signup'){mode=nextMode;renderAuth();auth.classList.add('show');document.getElementById('email').focus()}
document.getElementById('close')?.addEventListener('click',()=>auth.classList.remove('show'));
auth?.addEventListener('click',e=>{if(e.target===auth)auth.classList.remove('show')});
authSwitch?.addEventListener('click',()=>{mode=mode==='signup'?'login':'signup';renderAuth()});
authSubmit?.addEventListener('click',()=>{
  const email=document.getElementById('email').value.trim(),password=document.getElementById('pass').value;
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<6){authStatus.textContent=tr('authRequired');return}
  localStorage.setItem('univision_user_email',email);authStatus.textContent=tr('authSaved',{email});updateAuthUi();
  setTimeout(()=>auth.classList.remove('show'),700);
});
function renderAccount(){
  if(accountEmail)accountEmail.textContent=localStorage.getItem('univision_user_email')||tr('accountSignedOut');
  document.querySelectorAll('.account-tab').forEach(button=>button.textContent=tr(button.dataset.view==='universities'?'myUniversities':button.dataset.view==='settings'?'settings':'accountProfile'));
}
function openAccount(){renderAccount();accountModal.classList.add('show')}
document.getElementById('account')?.addEventListener('click',openAccount);
document.getElementById('loginBtn')?.addEventListener('click',e=>{
  e.preventDefault();
  if(localStorage.getItem('univision_user_email'))openAccount();else openAuth('signup');
});
document.getElementById('accountClose')?.addEventListener('click',()=>accountModal.classList.remove('show'));
accountModal?.addEventListener('click',e=>{if(e.target===accountModal)accountModal.classList.remove('show')});
document.querySelectorAll('.account-tab').forEach(button=>button.addEventListener('click',()=>{
  document.querySelectorAll('.account-view').forEach(panel=>panel.hidden=panel.dataset.viewPanel!==button.dataset.view);
}));
document.querySelectorAll('.home-tool').forEach(el=>el.addEventListener('click',()=>{const t=el.dataset.target;if(t)document.getElementById(t)?.scrollIntoView({behavior:'smooth'})}));
document.getElementById('compareBtn')?.addEventListener('click',runCompare);
async function boot(){await loadLocales();init();}
boot();
