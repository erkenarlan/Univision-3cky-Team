UniVision — FINAL LOADING/UI FIX

Fixed:
- Removed the apparent infinite loading caused by sequential 12s QS data requests.
- QS source requests now run in parallel with a single ~7.5s overall timeout.
- Wikipedia description now has a 4.5s timeout and no longer blocks the photo/profile flow.
- Photo search has a hard ~8.2s guard and stale concurrent searches cannot overwrite newer results.
- Reduced photo query fan-out while keeping parallel search.
- Loading UI now shows visual stages: 🌐 source → 📍 location → 📸 photos → ✓ verification → ✨ done.
- Added animated progress bar and clearer retry button.
- Campus/library/labs/dorm/sports/student-life sections keep the same search flow.
- Photo cards continue to show university name + 📍 location + source + verification level.

Validation:
- JavaScript syntax checked with Node.js `node --check`.
- Full browser click-through could not be executed in this environment because Playwright's Chromium binary is not installed.
